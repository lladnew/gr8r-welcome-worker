# GR8R Welcome Email Worker

This Cloudflare Worker sends a daily welcome email using MailerSend to new subscribers stored in Airtable.

## Setup

1. Set environment variables:

```
wrangler secret put AIRTABLE_API_KEY
wrangler secret put AIRTABLE_BASE_ID
wrangler secret put MAILERSEND_API_KEY
```

2. Deploy the Worker:

```
wrangler deploy
```

## Schedule

This Worker runs daily at 9am ET via cron.
